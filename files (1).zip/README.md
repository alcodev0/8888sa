# Telegram Music Mini App — Docker setup

Это готовая конфигурация для запуска backend-heavy Telegram Mini App в Docker (app + postgres + redis).

Что включено:
- Dockerfile для backend (multistage), с установкой yt-dlp (pip) и ffmpeg.
- docker-compose.yml запускает app, postgres (с init SQL), и redis.
- db/init/create_tables.sql — создаёт таблицу `tracks` при инициализации Postgres.
- Скрипт `scripts/wait-for.sh` ждёт доступности Postgres и Redis перед стартом приложения.

Запуск локально:
1. Скопируйте пример .env:
   cp .env.example .env
   и при необходимости отредактируйте значения.

2. Соберите и поднимите сервисы:
   docker compose up --build

3. Откройте http://localhost:3000 — на этом адресе будет доступен backend и статическая папка public (index.html).

Остановить:
   docker compose down

Примечания:
- yt-dlp устанавливается в образ через pip; убедитесь, что политика безопасности вашей среды позволяет это.
- Для окружений production рекомендуется:
  - Хранить секреты в безопасном хранилище (не в .env).
  - Использовать внешние тома/бэкапы для Postgres и Redis.
  - Перейти на managed сервисы или использовать CI/CD для сборки образов.
- Rate limiter в коде — in-memory; для production используйте redis-based rate limiter, если нужно масштабирование.

Если хотите, могу:
- Добавить docker-compose.override.yml (dev) с монтированием исходников и командой npm run dev.
- Подготовить Docker Hub / GitHub Actions workflow для автоматической сборки и публикации образа.
- Добавить healthcheck и readinessProbe в Kubernetes-манифесты.
