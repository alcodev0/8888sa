CREATE TABLE IF NOT EXISTS tracks (
  id SERIAL PRIMARY KEY,
  video_id VARCHAR(50) UNIQUE NOT NULL,
  title VARCHAR(500) NOT NULL,
  artist VARCHAR(200) DEFAULT '',
  thumbnail_url TEXT DEFAULT '',
  duration INTEGER DEFAULT 0,
  views BIGINT DEFAULT 0,
  is_music_video BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tracks_video_id ON tracks(video_id);
CREATE INDEX IF NOT EXISTS idx_tracks_is_music_video ON tracks(is_music_video);