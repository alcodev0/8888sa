import { Client } from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { tracks } from '../models/track.model';

type TrackDTO = {
  videoId: string;
  title: string;
  artist?: string;
  thumbnail?: string;
  duration?: number;
  views?: number;
  isMusicVideo?: boolean;
};

export default class MetadataService {
  private client: Client;
  private db: any;

  constructor(databaseUrl: string) {
    this.client = new Client({ connectionString: databaseUrl || process.env.DATABASE_URL });
    this.client.connect().catch((err) => console.warn('Postgres connect failed', err));
    this.db = drizzle(this.client);
  }

  async upsertTracks(tracksArr: TrackDTO[]) {
    for (const t of tracksArr) {
      try {
        await this.db.insert(tracks).values({
          videoId: t.videoId,
          title: t.title,
          artist: t.artist || '',
          thumbnail: t.thumbnail || '',
          duration: t.duration || 0,
          views: t.views || 0,
          isMusicVideo: t.isMusicVideo !== false
        }).onConflictDoNothing().execute();
      } catch (err) {
        console.warn('upsert track failed', err);
      }
    }
  }

  async findByVideoId(videoId: string) {
    try {
      const res = await this.db.select().from(tracks).where(tracks.videoId.eq(videoId)).limit(1).execute();
      return res[0] || null;
    } catch (err) {
      console.warn('db find error', err);
      return null;
    }
  }
}