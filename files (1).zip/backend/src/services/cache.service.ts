import Redis from 'ioredis';

export default class CacheService {
  constructor(private redis: Redis) {}

  async getStreamUrl(key: string): Promise<string | null> {
    try {
      return await this.redis.get(key);
    } catch (err) {
      console.warn('Redis get error', err);
      return null;
    }
  }

  async setStreamUrl(key: string, url: string, ttlSeconds: number) {
    try {
      await this.redis.set(key, url, 'EX', ttlSeconds);
    } catch (err) {
      console.warn('Redis set error', err);
    }
  }
}