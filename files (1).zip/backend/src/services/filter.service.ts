type TrackDTO = {
  videoId: string;
  title: string;
  artist?: string;
  thumbnail?: string;
  duration?: number;
  views?: number;
  isMusicVideo?: boolean;
};

export default class FilterService {
  private includeKeywords = ['official audio', 'lyrics', 'music video'];
  private excludeKeywords = ['podcast', 'interview', 'vlog', 'reaction'];

  guessIsMusicVideo(item: any): boolean {
    const title = (item.title || '').toLowerCase();
    const uploader = (item.uploader || '').toLowerCase();
    for (const ex of this.excludeKeywords) {
      if (title.includes(ex) || uploader.includes(ex)) return false;
    }
    for (const inc of this.includeKeywords) {
      if (title.includes(inc) || uploader.includes(inc)) return true;
    }
    const dur = Number(item.duration || 0);
    return dur > 30 && dur < 60 * 20;
  }

  filterMusicOnly(tracks: TrackDTO[]): TrackDTO[] {
    return tracks.filter((t) => {
      const title = (t.title || '').toLowerCase();
      if (!t.videoId) return false;
      for (const ex of this.excludeKeywords) {
        if (title.includes(ex)) return false;
      }
      const hasInclude = this.includeKeywords.some((k) => title.includes(k));
      if (hasInclude) return true;
      if (typeof t.isMusicVideo === 'boolean') return t.isMusicVideo;
      if (t.duration && t.duration > 30 && t.duration < 60 * 20) return true;
      return false;
    });
  }
}