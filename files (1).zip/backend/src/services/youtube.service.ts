import { promisify } from 'util';
import { execFile } from 'child_process';
const execFileAsync = promisify(execFile);

export default class YouTubeService {
  constructor(private ytDlpPath: string = 'yt-dlp') {}

  async search(query: string, limit = 15): Promise<any[]> {
    const searchTarget = `ytsearch${limit}:${query}`;
    const args = [searchTarget, '--dump-json', '--skip-download'];
    try {
      const { stdout } = await execFileAsync(this.ytDlpPath, args, { maxBuffer: 20 * 1024 * 1024 });
      const lines = stdout.split('\n').filter(Boolean);
      return lines.map((l) => { try { return JSON.parse(l); } catch (e) { return null; } }).filter(Boolean);
    } catch (err: any) {
      console.error('yt-dlp search error', err?.stderr || err);
      throw err;
    }
  }

  async getStreamUrl(videoId: string): Promise<string | null> {
    const url = `https://www.youtube.com/watch?v=${videoId}`;
    const args = ['-f', 'bestaudio', '--get-url', url];
    try {
      const { stdout } = await execFileAsync(this.ytDlpPath, args, { maxBuffer: 20 * 1024 * 1024 });
      const out = stdout.trim();
      const firstLine = out.split('\n')[0];
      return firstLine || null;
    } catch (err: any) {
      console.error('yt-dlp get-url error', err?.stderr || err);
      return null;
    }
  }
}