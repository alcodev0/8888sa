import express from 'express';
import path from 'path';
import { json } from 'body-parser';
import Redis from 'ioredis';
import corsMiddleware from './middleware/cors.middleware';
import errorMiddleware from './middleware/error.middleware';
import rateMiddleware from './middleware/rate.middleware';
import SearchController from './controllers/search.controller';
import StreamController from './controllers/stream.controller';
import TrackController from './controllers/track.controller';
import CacheService from './services/cache.service';
import YouTubeService from './services/youtube.service';
import FilterService from './services/filter.service';
import MetadataService from './services/metadata.service';

const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;

async function main() {
  const redisUrl = process.env.REDIS_URL || 'redis://redis:6379';
  const redis = new Redis(redisUrl);

  const cacheService = new CacheService(redis);
  const ytService = new YouTubeService(process.env.YT_DLP_PATH || 'yt-dlp');
  const filterService = new FilterService();
  const metadataService = new MetadataService(process.env.DATABASE_URL || '');

  const searchController = new SearchController(ytService, filterService, cacheService, metadataService);
  const streamController = new StreamController(ytService, cacheService);
  const trackController = new TrackController(metadataService);

  const app = express();
  app.use(json());
  app.use(corsMiddleware());
  app.use(rateMiddleware({ requestsPerSecond: 5 }));

  app.get('/api/search', (req, res, next) => searchController.search(req, res, next));
  app.get('/api/stream/:videoId', (req, res, next) => streamController.stream(req, res, next));
  app.get('/api/tracks/:videoId', (req, res, next) => trackController.getTrackByVideoId(req, res, next));

  app.use(express.static(path.join(__dirname, '..', '..', 'public')));
  app.get('/health', (_req, res) => res.json({ ok: true }));
  app.use(errorMiddleware);

  app.listen(PORT, () => {
    console.log(`Server started on port ${PORT}`);
  });

  process.on('SIGINT', async () => {
    console.log('Shutting down...');
    try { await redis.quit(); } catch (e) {}
    process.exit(0);
  });
}

main().catch((err) => {
  console.error('Startup error', err);
  process.exit(1);
});