import { pgTable, serial, varchar, text, integer, bigint, boolean, timestamp } from 'drizzle-orm/pg-core';

export const tracks = pgTable('tracks', {
  id: serial('id').primaryKey(),
  videoId: varchar('video_id', { length: 50 }).unique(),
  title: varchar('title', { length: 500 }),
  artist: varchar('artist', { length: 200 }),
  thumbnail: text('thumbnail_url'),
  duration: integer('duration'),
  views: bigint('views', { mode: 'number' }),
  isMusicVideo: boolean('is_music_video').default(true),
  createdAt: timestamp('created_at').defaultNow()
});