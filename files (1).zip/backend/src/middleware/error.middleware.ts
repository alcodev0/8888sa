import { Request, Response, NextFunction } from 'express';
export default function errorMiddleware(err: any, _req: Request, res: Response, _next: NextFunction) {
  console.error('Unhandled error:', err && err.stack ? err.stack : err);
  const status = err && err.status ? err.status : 500;
  const message = err && err.message ? err.message : 'Internal Server Error';
  res.status(status).json({ error: message });
}