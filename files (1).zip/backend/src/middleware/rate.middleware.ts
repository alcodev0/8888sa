import { Request, Response, NextFunction } from 'express';
type Bucket = { tokens: number; lastRefill: number; };
export default function rateMiddleware(opts: { requestsPerSecond: number }) {
  const store = new Map<string, Bucket>();
  const capacity = opts.requestsPerSecond;
  const refillRate = opts.requestsPerSecond;
  return function (req: Request, res: Response, next: NextFunction) {
    try {
      const ip = (req.ip || req.headers['x-forwarded-for'] || 'unknown').toString();
      const now = Date.now();
      let b = store.get(ip);
      if (!b) { b = { tokens: capacity, lastRefill: now }; store.set(ip, b); }
      const deltaSec = (now - b.lastRefill) / 1000;
      b.tokens = Math.min(capacity, b.tokens + deltaSec * refillRate);
      b.lastRefill = now;
      if (b.tokens >= 1) { b.tokens -= 1; next(); } else { res.status(429).json({ error: 'Too Many Requests' }); }
    } catch (err) { next(err); }
  };
}