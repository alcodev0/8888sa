import cors from 'cors';
export default function corsMiddleware() {
  return cors({
    origin: function (_origin, cb) { cb(null, true); },
    methods: ['GET', 'POST', 'OPTIONS'],
    credentials: true,
    allowedHeaders: ['Content-Type', 'Authorization']
  });
}