import { Request, Response, NextFunction } from 'express';
import YouTubeService from '../services/youtube.service';
import FilterService from '../services/filter.service';
import CacheService from '../services/cache.service';
import MetadataService from '../services/metadata.service';

type TrackDTO = {
  videoId: string;
  title: string;
  artist?: string;
  thumbnail?: string;
  duration?: number;
  views?: number;
  isMusicVideo?: boolean;
};

export default class SearchController {
  constructor(
    private yt: YouTubeService,
    private filter: FilterService,
    private cache: CacheService,
    private metadata: MetadataService
  ) {}

  async search(req: Request, res: Response, next: NextFunction) {
    try {
      const q = String(req.query.q || '').trim();
      if (!q) return res.status(400).json({ error: 'q is required' });

      const raw = await this.yt.search(q);
      const mapped: TrackDTO[] = raw.map((item: any) => {
        const vid = item.id || item.webpage_url?.split('v=')[1] || null;
        return {
          videoId: vid,
          title: item.title || '',
          artist: item.uploader || item.artist || '',
          thumbnail: item.thumbnail || '',
          duration: item.duration || 0,
          views: item.view_count || 0,
          isMusicVideo: this.filter.guessIsMusicVideo(item)
        };
      }).filter((t: any) => t && t.videoId);

      const musicOnly = this.filter.filterMusicOnly(mapped);
      // async upsert, non-blocking
      this.metadata.upsertTracks(musicOnly).catch((err) => console.warn('upsert error', err));

      return res.json({ results: musicOnly });
    } catch (err) {
      next(err);
    }
  }
}