import { Request, Response, NextFunction } from 'express';
import MetadataService from '../services/metadata.service';

export default class TrackController {
  constructor(private metadata: MetadataService) {}

  async getTrackByVideoId(req: Request, res: Response, next: NextFunction) {
    try {
      const videoId = String(req.params.videoId || '').trim();
      if (!videoId) return res.status(400).json({ error: 'videoId required' });

      const track = await this.metadata.findByVideoId(videoId);
      if (!track) return res.status(404).json({ error: 'not found' });

      return res.json({ track });
    } catch (err) {
      next(err);
    }
  }
}