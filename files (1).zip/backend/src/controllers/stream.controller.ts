import { Request, Response, NextFunction } from 'express';
import YouTubeService from '../services/youtube.service';
import CacheService from '../services/cache.service';

export default class StreamController {
  constructor(private yt: YouTubeService, private cache: CacheService) {}

  async stream(req: Request, res: Response, next: NextFunction) {
    try {
      const videoId = String(req.params.videoId || '').trim();
      if (!videoId) return res.status(400).json({ error: 'videoId required' });

      const cacheKey = `stream:${videoId}`;
      let url = await this.cache.getStreamUrl(cacheKey);
      if (url) return res.json({ streamUrl: url, cached: true });

      url = await this.yt.getStreamUrl(videoId);
      if (!url) return res.status(502).json({ error: 'unable to get stream url' });

      await this.cache.setStreamUrl(cacheKey, url, 60 * 60 * 6);
      return res.json({ streamUrl: url, cached: false });
    } catch (err) {
      next(err);
    }
  }
}