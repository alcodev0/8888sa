#!/bin/bash
set -e
: "${POSTGRES_HOST:=postgres}"
: "${POSTGRES_PORT:=5432}"
: "${REDIS_HOST:=redis}"
: "${REDIS_PORT:=6379}"
: "${START_CMD:=node dist/index.js}"

echo "Waiting for Postgres at ${POSTGRES_HOST}:${POSTGRES_PORT}..."
while ! bash -c "cat < /dev/tcp/${POSTGRES_HOST}/${POSTGRES_PORT}" >/dev/null 2>&1; do sleep 1; done
echo "Postgres reachable."

echo "Waiting for Redis at ${REDIS_HOST}:${REDIS_PORT}..."
while ! bash -c "cat < /dev/tcp/${REDIS_HOST}/${REDIS_PORT}" >/dev/null 2>&1; do sleep 1; done
echo "Redis reachable."

echo "Starting app..."
exec ${START_CMD}