# Деплой в Kubernetes — инструкции

Эти инструкции описывают подготовку репозитория и запуск CI/CD (GitHub Actions), который собирает Docker-образ и деплоит в Kubernetes.

1) Создайте репозитории на GitHub и запушьте весь код.

2) Настройте секреты в GitHub (Repository Settings → Secrets and variables → Actions):
   - KUBE_CONFIG — base64-encoded kubeconfig (оставьте пустым, если не используете k8s деплой)
     - Пример: base64 < ~/.kube/config | pbcopy
   - DATABASE_URL — connection string к вашей базе в проде (если используете managed Postgres)
   - REDIS_URL — connection string к Redis
   - TELEGRAM_BOT_TOKEN — token вашего бота

3) Опционально: разрешения workflow (вверху файла) уже запрашивают packages: write (для GHCR).

4) Домены:
   - В `k8s/ingress.yaml` замените host на ваш домен (app.example.com).
   - Настройте Ingress Controller (nginx/contour/traefik) и TLS (Cert-Manager или провайдер).

5) Запуск:
   - При пуше в ветку `main` Actions соберёт образ и пушит в GHCR.
   - Если `KUBE_CONFIG` задан — workflow применит манифесты и обновит deployment image автоматически.

6) Примечания:
   - GHCR: образ будет доступен как ghcr.io/<org_or_user>/telegram-music-miniapp:latest и :<sha>.
   - Secrets в Kubernetes создаются из GitHub Actions (в workflow предусмотрено).
   - Если вы используете Cloud SQL / managed Postgres — убедитесь, что сетевые правила позволяют подключение из кластера.

Если хотите, могу подготовить:
- workflow для Render / Fly / DigitalOcean App Platform (деплой без k8s),
- GitHub Actions секретную интеграцию для Render (render.yaml) или Fly (flyctl),
- готовые Terraform-манифесты для GKE/EKS/AKS или манифесты для Helm.